--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4 (Debian 11.4-1.pgdg90+1)
-- Dumped by pg_dump version 14.5 (Ubuntu 14.5-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE db_riquinho;
--
-- Name: db_riquinho; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE db_riquinho WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE db_riquinho OWNER TO postgres;

\connect db_riquinho

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: meta_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.meta_status_enum AS ENUM (
    'EM_ANDAMENTO',
    'FINALIZADA'
);


ALTER TYPE public.meta_status_enum OWNER TO postgres;

--
-- Name: parcela_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.parcela_status_enum AS ENUM (
    'EFETIVADA',
    'PENDENTE'
);


ALTER TYPE public.parcela_status_enum OWNER TO postgres;

--
-- Name: transacao_tipo_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transacao_tipo_enum AS ENUM (
    'RECEITA',
    'DESPESA',
    'META'
);


ALTER TYPE public.transacao_tipo_enum OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nome character varying NOT NULL,
    icon character varying NOT NULL,
    color character varying NOT NULL,
    is_for_receita boolean NOT NULL,
    is_for_despesa boolean NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    user_id uuid NOT NULL,
    created_at date DEFAULT now() NOT NULL,
    updated_at date DEFAULT now() NOT NULL
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: database_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.database_migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.database_migrations OWNER TO postgres;

--
-- Name: database_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.database_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.database_migrations_id_seq OWNER TO postgres;

--
-- Name: database_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.database_migrations_id_seq OWNED BY public.database_migrations.id;


--
-- Name: meta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meta (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    valor numeric(10,2) NOT NULL,
    progresso numeric(10,2) NOT NULL,
    prazo integer NOT NULL,
    descricao character varying,
    titulo character varying NOT NULL,
    data_inicio date NOT NULL,
    status public.meta_status_enum NOT NULL,
    transacao_id uuid NOT NULL,
    created_at date DEFAULT now() NOT NULL,
    updated_at date DEFAULT now() NOT NULL
);


ALTER TABLE public.meta OWNER TO postgres;

--
-- Name: parcela; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parcela (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    status public.parcela_status_enum NOT NULL,
    valor numeric(10,2) NOT NULL,
    data date NOT NULL,
    descricao character varying NOT NULL,
    transacao_id uuid NOT NULL,
    created_at date DEFAULT now() NOT NULL,
    updated_at date DEFAULT now() NOT NULL
);


ALTER TABLE public.parcela OWNER TO postgres;

--
-- Name: transacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transacao (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    titulo character varying NOT NULL,
    descricao character varying,
    tipo public.transacao_tipo_enum NOT NULL,
    parcelado boolean NOT NULL,
    created_at date DEFAULT now() NOT NULL,
    updated_at date DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    categoria_id uuid NOT NULL,
    meta_id uuid
);


ALTER TABLE public.transacao OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nome character varying NOT NULL,
    email character varying NOT NULL,
    senha character varying NOT NULL,
    created_at date DEFAULT now() NOT NULL,
    updated_at date DEFAULT now() NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: database_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.database_migrations ALTER COLUMN id SET DEFAULT nextval('public.database_migrations_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (id, nome, icon, color, is_for_receita, is_for_despesa, is_default, user_id, created_at, updated_at) FROM stdin;
\.
COPY public.categoria (id, nome, icon, color, is_for_receita, is_for_despesa, is_default, user_id, created_at, updated_at) FROM '$$PATH$$/2946.dat';

--
-- Data for Name: database_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.database_migrations (id, "timestamp", name) FROM stdin;
\.
COPY public.database_migrations (id, "timestamp", name) FROM '$$PATH$$/2943.dat';

--
-- Data for Name: meta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meta (id, valor, progresso, prazo, descricao, titulo, data_inicio, status, transacao_id, created_at, updated_at) FROM stdin;
\.
COPY public.meta (id, valor, progresso, prazo, descricao, titulo, data_inicio, status, transacao_id, created_at, updated_at) FROM '$$PATH$$/2948.dat';

--
-- Data for Name: parcela; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parcela (id, status, valor, data, descricao, transacao_id, created_at, updated_at) FROM stdin;
\.
COPY public.parcela (id, status, valor, data, descricao, transacao_id, created_at, updated_at) FROM '$$PATH$$/2947.dat';

--
-- Data for Name: transacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transacao (id, titulo, descricao, tipo, parcelado, created_at, updated_at, user_id, categoria_id, meta_id) FROM stdin;
\.
COPY public.transacao (id, titulo, descricao, tipo, parcelado, created_at, updated_at, user_id, categoria_id, meta_id) FROM '$$PATH$$/2944.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, nome, email, senha, created_at, updated_at) FROM stdin;
\.
COPY public."user" (id, nome, email, senha, created_at, updated_at) FROM '$$PATH$$/2945.dat';

--
-- Name: database_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.database_migrations_id_seq', 6, true);


--
-- Name: parcela PK_2346e2ab15354b0327c0123b59c; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parcela
    ADD CONSTRAINT "PK_2346e2ab15354b0327c0123b59c" PRIMARY KEY (id);


--
-- Name: database_migrations PK_541706ccec0da007ddb910d07de; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.database_migrations
    ADD CONSTRAINT "PK_541706ccec0da007ddb910d07de" PRIMARY KEY (id);


--
-- Name: transacao PK_8a60051729f5d7e2d49c8fa91c5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT "PK_8a60051729f5d7e2d49c8fa91c5" PRIMARY KEY (id);


--
-- Name: meta PK_c4c17a6c2bd7651338b60fc590b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meta
    ADD CONSTRAINT "PK_c4c17a6c2bd7651338b60fc590b" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: categoria PK_f027836b77b84fb4c3a374dc70d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT "PK_f027836b77b84fb4c3a374dc70d" PRIMARY KEY (id);


--
-- Name: categoria FK_CATEGORIA_ID_USER; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT "FK_CATEGORIA_ID_USER" FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: meta FK_META_ID_TRANSACAO; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meta
    ADD CONSTRAINT "FK_META_ID_TRANSACAO" FOREIGN KEY (transacao_id) REFERENCES public.transacao(id) ON DELETE CASCADE;


--
-- Name: parcela FK_PARCELA_ID_TRANSACAO; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parcela
    ADD CONSTRAINT "FK_PARCELA_ID_TRANSACAO" FOREIGN KEY (transacao_id) REFERENCES public.transacao(id) ON DELETE CASCADE;


--
-- Name: transacao FK_TRANSACAO_ID_CATEGORIA; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT "FK_TRANSACAO_ID_CATEGORIA" FOREIGN KEY (categoria_id) REFERENCES public.categoria(id) ON DELETE CASCADE;


--
-- Name: transacao FK_TRANSACAO_ID_META; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT "FK_TRANSACAO_ID_META" FOREIGN KEY (meta_id) REFERENCES public.meta(id) ON DELETE CASCADE;


--
-- Name: transacao FK_TRANSACAO_ID_USER; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT "FK_TRANSACAO_ID_USER" FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

